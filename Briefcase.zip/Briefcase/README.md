Briefcase Legacy - A Modern Homage to a Windows Classic ("By: Windows98Editor|Github ID: windows98editorz")
A simple, offline, two-way file synchronization tool inspired by the classic Windows Briefcase feature. This project resurrects the straightforward functionality of the original Briefcase for modern systems, providing a lightweight, no-cloud solution for keeping files in sync between a computer and a removable drive.
🌟 Introduction
Remember the little suitcase icon from Windows 95, XP, and 7? Windows Briefcase was a brilliant utility for a time before the cloud dominated our lives. It offered a simple way to synchronize files between two locations, typically a desktop PC and a laptop or a floppy disk. It was simple, effective, and worked entirely offline.
This project, Briefcase Legacy, is a tribute to that iconic feature. It recreates the core functionality of Windows Briefcase with a clean, familiar interface. It's built for those who need a quick, no-frills, offline synchronization tool without the overhead of cloud services, accounts, or internet connections.
🤔 Why Briefcase Legacy?
In an era of OneDrive, Google Drive, and Dropbox, why build a tool like this?
Offline First: It works without an internet connection. Perfect for syncing files to a USB drive for use on a computer that is offline or on a restricted network.
No Accounts, No Subscriptions: Your data is yours. There's no need to create an account, sign in, or worry about privacy policies. Your files are never sent to a third-party server.
Simplicity & Control: Cloud services can be complex. Briefcase Legacy does one thing and does it well: it compares two folders and lets you update them with a single click. You have full control over the process.
Nostalgia & Learning: This project started as a fun challenge to replicate a beloved piece of software from the past and explore the logic behind file synchronization.
✨ Features
Familiar UI: An intuitive interface that mirrors the look and feel of the original Windows Briefcase.
Two-Way Synchronization: Select a "Source" and a "Briefcase" folder to keep them in sync.
Status Analysis: The application scans both folders and displays the status of each file:
Up To Date: The file is identical in both locations.
Needs Update: The file has been modified in one location and needs to be copied to the other.
(Future) Conflict: The file has been changed in both locations independently.
Timestamp-Based Comparison: Synchronization logic is based on the "Last Modified" timestamp of the files.
One-Click Update: The "Update All" button intelligently resolves all changes, ensuring both folders contain the latest versions of your files.
Lightweight & Portable: A small-footprint application with no complex dependencies.
🛠️ How It Works
The logic is straightforward:
Select Folders: The user specifies a Source directory and a Briefcase directory.
Scan: The application recursively scans both folders, creating a list of all unique files across both.
Compare: For each file, it compares the Last Modified timestamps.
If a file exists in only one location, it's marked as needing to be copied to the other.
If the file exists in both, their timestamps are compared. The location with the older file is marked as needing an update.
If the timestamps are identical, the file is marked as Up To Date.
Update: When the user clicks "Update All", the application performs the necessary file copy operations, copying the newer file over the older one in the appropriate direction.
Note:Dont Delete briefcase.png from Briefcase\Open This
🚀 Getting Started