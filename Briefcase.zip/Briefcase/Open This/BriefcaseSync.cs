using System;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace Win98Briefcase
{
    public enum FileStatus { UpToDate, NewInSource, NewInBriefcase, SourceNewer, BriefcaseNewer, Conflict, MissingBoth }

    public class FileItem
    {
        public string RelativePath;
        public string SourcePath;
        public string BriefcasePath;
        public DateTime SourceWrite;
        public DateTime BriefcaseWrite;
        public FileStatus Status;
    }

    public class BriefcaseManager
    {
        public string SourceDir;
        public string BriefcaseDir;

        public BriefcaseManager(string sourceDir, string briefcaseDir)
        {
            SourceDir = sourceDir;
            BriefcaseDir = briefcaseDir;
            if (!Directory.Exists(SourceDir)) Directory.CreateDirectory(SourceDir);
            if (!Directory.Exists(BriefcaseDir)) Directory.CreateDirectory(BriefcaseDir);
        }

        public List<FileItem> Scan()
        {
            Dictionary<string, FileItem> items = new Dictionary<string, FileItem>(StringComparer.OrdinalIgnoreCase);

            foreach (string s in Directory.GetFiles(SourceDir, "*", SearchOption.AllDirectories))
            {
                string rel = s.Substring(SourceDir.Length).TrimStart(Path.DirectorySeparatorChar);

                FileItem it;
                if (!items.TryGetValue(rel, out it))
                {
                    it = new FileItem { RelativePath = rel };
                    items[rel] = it;
                }

                it.SourcePath = s;
                it.SourceWrite = File.GetLastWriteTime(s);
            }

            foreach (string b in Directory.GetFiles(BriefcaseDir, "*", SearchOption.AllDirectories))
            {
                string rel = b.Substring(BriefcaseDir.Length).TrimStart(Path.DirectorySeparatorChar);

                FileItem it;
                if (!items.TryGetValue(rel, out it))
                {
                    it = new FileItem { RelativePath = rel };
                    items[rel] = it;
                }

                it.BriefcasePath = b;
                it.BriefcaseWrite = File.GetLastWriteTime(b);
            }

            foreach (FileItem it in items.Values)
            {
                bool hasSource = !string.IsNullOrEmpty(it.SourcePath) && File.Exists(it.SourcePath);
                bool hasBrief = !string.IsNullOrEmpty(it.BriefcasePath) && File.Exists(it.BriefcasePath);

                if (!hasSource && !hasBrief) it.Status = FileStatus.MissingBoth;
                else if (hasSource && !hasBrief) it.Status = FileStatus.NewInSource;
                else if (!hasSource && hasBrief) it.Status = FileStatus.NewInBriefcase;
                else if (it.SourceWrite > it.BriefcaseWrite) it.Status = FileStatus.SourceNewer;
                else if (it.BriefcaseWrite > it.SourceWrite) it.Status = FileStatus.BriefcaseNewer;
                else it.Status = FileStatus.UpToDate;
            }

            return new List<FileItem>(items.Values);
        }

        public void SyncItem(FileItem item)
        {
            if (item.Status == FileStatus.NewInSource || item.Status == FileStatus.SourceNewer)
                CopyFile(item.SourcePath, Path.Combine(BriefcaseDir, item.RelativePath));
            else if (item.Status == FileStatus.NewInBriefcase || item.Status == FileStatus.BriefcaseNewer)
                CopyFile(item.BriefcasePath, Path.Combine(SourceDir, item.RelativePath));
        }

        private void CopyFile(string src, string dst)
        {
            string dir = Path.GetDirectoryName(dst);
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            File.Copy(src, dst, true);
        }
    }

    public class BriefcaseForm : Form
    {
        private TextBox txtSource, txtBrief;
        private Button btnPickSource, btnPickBrief, btnScan, btnUpdateAll;
        private ListView lv;
        private PictureBox logo;
        private BriefcaseManager manager;

        public BriefcaseForm()
        {
            Text = "Briefcase";
            Width = 850; Height = 600;
            BackColor = Color.FromArgb(212, 208, 200); 
            Font = new Font("MS Sans Serif", 9F, FontStyle.Regular);

            logo = new PictureBox
            {
                Image = Image.FromFile("briefcase.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Left = 10,
                Top = 10,
                Width = 32,
                Height = 32,
                BorderStyle = BorderStyle.Fixed3D
            };

            Label lblS = new Label { Text = "Source:", Left = 60, Top = 20, Width = 80, BackColor = Color.Transparent };
            txtSource = CreateClassicTextbox(140, 18);
            btnPickSource = CreateClassicButton("Browse", 660, 17);

            Label lblB = new Label { Text = "Briefcase:", Left = 60, Top = 50, Width = 80, BackColor = Color.Transparent };
            txtBrief = CreateClassicTextbox(140, 48);
            btnPickBrief = CreateClassicButton("Browse", 660, 47);

            btnScan = CreateClassicButton("Scan", 750, 17);
            btnUpdateAll = CreateClassicButton("Update All", 750, 47);

            lv = new ListView
            {
                Left = 10,
                Top = 100,
                Width = 820,
                Height = 440,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                BorderStyle = BorderStyle.Fixed3D,
                Font = new Font("MS Sans Serif", 9F),
                BackColor = Color.White
            };
            lv.Columns.Add("File", 400);
            lv.Columns.Add("Status", 120);
            lv.Columns.Add("Source Time", 140);
            lv.Columns.Add("Briefcase Time", 140);

            Controls.AddRange(new Control[] {
                logo, lblS, txtSource, btnPickSource,
                lblB, txtBrief, btnPickBrief,
                btnScan, btnUpdateAll, lv
            });

            btnPickSource.Click += delegate { string p = PickFolder(); if (p != "") txtSource.Text = p; };
            btnPickBrief.Click += delegate { string p = PickFolder(); if (p != "") txtBrief.Text = p; };
            btnScan.Click += delegate { InitAndScan(); };
            btnUpdateAll.Click += delegate { UpdateAll(); };
        }

        private TextBox CreateClassicTextbox(int left, int top)
        {
            return new TextBox
            {
                Left = left,
                Top = top,
                Width = 500,
                BorderStyle = BorderStyle.Fixed3D,
                BackColor = Color.White,
                Font = new Font("MS Sans Serif", 9F)
            };
        }

        private Button CreateClassicButton(string text, int left, int top)
        {
            return new Button
            {
                Text = text,
                Left = left,
                Top = top,
                Width = 80,
                Height = 24,
                FlatStyle = FlatStyle.Standard,
                Font = new Font("MS Sans Serif", 9F),
                BackColor = Color.FromArgb(212, 208, 200),
                UseVisualStyleBackColor = true
            };
        }

        private void InitAndScan()
        {
            if (txtSource.Text == "" || txtBrief.Text == "")
            {
                MessageBox.Show("Select both folders.", "Briefcase", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            manager = new BriefcaseManager(txtSource.Text, txtBrief.Text);
            RefreshList();
        }

        private void RefreshList()
        {
            lv.Items.Clear();
            List<FileItem> list = manager.Scan();
            foreach (FileItem item in list)
            {
                ListViewItem li = new ListViewItem(new string[] {
                    item.RelativePath,
                    item.Status.ToString(),
                    item.SourceWrite == DateTime.MinValue ? "" : item.SourceWrite.ToString(),
                    item.BriefcaseWrite == DateTime.MinValue ? "" : item.BriefcaseWrite.ToString()
                });
                lv.Items.Add(li);
            }
        }

        private void UpdateAll()
        {
            if (manager == null)
            {
                MessageBox.Show("Scan first.", "Briefcase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            List<FileItem> list = manager.Scan();
            foreach (FileItem item in list) manager.SyncItem(item);
            RefreshList();
        }

        private string PickFolder()
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK) return fbd.SelectedPath;
            return "";
        }
    }

    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new BriefcaseForm());
        }
    }
}
